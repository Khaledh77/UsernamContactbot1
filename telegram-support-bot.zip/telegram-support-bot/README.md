# Telegram Support Bot 🤖

Bu bot — Telegram orqali foydalanuvchilarning xabarlarini adminga yuborish uchun mo‘ljallangan ko‘p tilli (🇬🇧 English, 🇷🇺 Русский, 🇺🇿 O‘zbekcha) aloqa (support) botdir.

---

## ⚙️ Xususiyatlari:

- `/start` bosilganda til tanlash tugmalari chiqadi (🇬🇧, 🇷🇺, 🇺🇿)
- Foydalanuvchi savol yozadi yoki fayl yuboradi
- Bot bu xabarni avtomatik tarzda adminga yuboradi
- Admin foydalanuvchining:
  - Ismi
  - Username
  - Telegram ID
  - Xabar матни ва файлни кўради
- Bot foydalanuvchiга “Rahmat” сингари жавоб қайтаради

---

## 🛠 O‘rnatish (Install)

1. Loyihani klon qiling:

```bash
git clone https://github.com/Khaledh77/support-bot.git
cd support-bot