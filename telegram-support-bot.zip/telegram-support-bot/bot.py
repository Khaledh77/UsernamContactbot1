import logging
import os
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from dotenv import load_dotenv

# .env файлдан токен ва админ ID ни олиш
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

# Бот ва диспетчерни тайёрлаш
logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())

# Тил танлаш тугмалари
lang_kb = ReplyKeyboardMarkup(resize_keyboard=True)
lang_kb.add(
    KeyboardButton("🇬🇧 English"),
    KeyboardButton("🇷🇺 Русский"),
    KeyboardButton("🇺🇿 O'zbekcha")
)

# Фойдаланувчи танлаган тилни сақлаш учун
user_language = {}

# /start буйруғи
@dp.message_handler(commands=["start"])
async def send_welcome(message: types.Message):
    await message.answer("Please choose your language / Пожалуйста, выберите язык / Илтимос, тил танланг:", reply_markup=lang_kb)

# Тил танлаш
@dp.message_handler(lambda message: message.text in ["🇬🇧 English", "🇷🇺 Русский", "🇺🇿 O'zbekcha"])
async def set_language(message: types.Message):
    user_language[message.from_user.id] = message.text

    if message.text == "🇬🇧 English":
        text = "🇬🇧 If you have any questions — feel free to write us. We will contact you soon.\nYou can attach any file: audio, video, PDF, image, etc."
    elif message.text == "🇷🇺 Русский":
        text = "🇷🇺 Если у вас есть вопросы — напишите нам, и мы скоро с вами свяжемся.\nВы можете прикрепить любые файлы: аудио, видео, PDF, фото и т.д."
    else:
        text = "🇺🇿 Savollaringiz bo‘lsa, bizga yuboring — tez orada siz bilan aloqaga chiqamiz.\nXabar yuborishda istalgan faylni (audio, video, PDF, rasm ва ҳ.к.) qo‘shishingiz mumkin."

    await message.answer(text, reply_markup=types.ReplyKeyboardRemove())

# Ҳар қандай хабарни қабул қилиш ва админга юбориш
@dp.message_handler(content_types=types.ContentTypes.ANY)
async def forward_to_admin(message: types.Message):
    lang = user_language.get(message.from_user.id, "🇬🇧 English")

    # Админга хабар тайёрлаш
    caption = f"📩 Yangi xabar:\n\n👤 Ism: {message.from_user.full_name}\n"
    caption += f"🔗 Username: @{message.from_user.username if message.from_user.username else 'yo‘q'}\n"
    caption += f"🆔 ID: {message.from_user.id}\n\n"

    if message.text:
        caption += f"💬 Xabar: {message.text}"

    try:
        if message.content_type == "text":
            await bot.send_message(ADMIN_ID, caption)
        elif message.content_type in ["photo", "document", "video", "audio", "voice", "video_note"]:
            file = getattr(message, message.content_type)
            await file[-1].download() if isinstance(file, list) else None
            await message.send_copy(ADMIN_ID, caption=caption)
        else:
            await bot.send_message(ADMIN_ID, caption + "\n📎 (файл бор)")
    except Exception as e:
        await message.reply("Xatolik yuz berdi: " + str(e))

    # Фойдаланувчига автоматик жавоб
    if lang == "🇬🇧 English":
        reply = "🇬🇧 Thank you! Your message has been sent to the admin. We will contact you soon."
    elif lang == "🇷🇺 Русский":
        reply = "🇷🇺 Спасибо! Ваше сообщение отправлено администратору. Мы скоро с вами свяжемся."
    else:
        reply = "🇺🇿 Raxmat, xabaringizni adminga yubordim. Admin tez orada siz bilan aloqaga chiqadi."

    await message.reply(reply)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)